// ==========================================================================
// brain.h — «мозг» робота (порт ai_brain.py -> ESP8266).
// Провайдеры: offline (демо-ответы), local (свой ИИ: Ollama/LM Studio/
// llama.cpp), openai (любой OpenAI-совместимый API). Тот же системный
// промпт с тегами эмоций и тот же парсер, что в симуляторе и brain.cpp v3.
//
// ВАЖНО (ESP8266): FreeRTOS отсутствует. Вместо фоновой задачи запрос
// выполняется синхронно из poll() — см. brain.cpp. Интерфейс класса
// (begin/askAsync/poll/busy) остался прежним, менять вызывающий код не нужно.
// ==========================================================================
#pragma once
#include <Arduino.h>
#include <vector>

struct HistLine {            // одна реплика истории чата
  String role;               // "user" | "assistant"
  String content;
};

struct BrainRsp {            // ответ мозга -> главный цикл
  bool ok;
  String text;               // чистый текст ответа (без тега)
  String emo;                // эмоция из тега ("" если нет)
  String err;                // текст ошибки (ok == false)
};

class RobotBrain {
public:
  void begin();              // на ESP8266 ничего не создаёт (нет очередей)
  void askAsync(const String &text, const std::vector<HistLine> &hist);

  // Забрать готовый ответ (не блокирует). true — ответ получен.
  bool poll(BrainRsp &out);

  bool busy() const { return _busy; }

private:
  BrainRsp _ask(const String &text, const std::vector<HistLine> &hist);
  BrainRsp _offline(const String &text);
  BrainRsp _openaiCompatible(const String &base, const String &key,
                             const String &model,
                             const String &text,
                             const std::vector<HistLine> &hist,
                             uint32_t timeout_ms);

  volatile bool _busy = false;
};

// Парсер тега эмоции: ищет [радость] / [happy] / <emotion>happy</emotion>.
// Возвращает эмоцию ("" если не найдена) и вырезает тег из текста.
String brainParseEmotion(String &text);

extern const char* SYSTEM_PROMPT;