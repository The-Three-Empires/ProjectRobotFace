// ==========================================================================
// config.h — пины, константы и настройки RobotFace ESP32.
// Аналог sim_config.py из ПК-симулятора (там настройки жили в JSON,
// здесь — в энергонезависимой памяти NVS, меняются через веб-пульт).
// ==========================================================================
#pragma once
#include <Arduino.h>

// --------------------------- Дисплей (TFT 80x160) -------------------------
// // Мы уменьшаем логические координаты, чтобы лицо поместилось на маленький экран.
// #define FACE_W 80
// #define FACE_H 160

// ----------------------------- Wi-Fi и веб-пульт ---------------------------
#define ROBOT_HOSTNAME   "robotface"       // -> http://robotface.local
#define AP_SSID          "RobotFace"       // точка доступа, если Wi-Fi не задан
#define AP_PASS          "12345678"
#define WIFI_STA_TIMEOUT 12000             // мс ожидания подключения к роутеру

// ------------------------------- Поведение ---------------------------------
#define SLEEPY_AFTER_MS  45000   // бездействие -> эмоция «сонность»
#define OSD_MS           1600    // сколько висит плашка «эмоция N/16»
#define SPEAK_MS_PER_CHAR 45     // длительность SPEAK от длины ответа
#define DEMO_STEP_MS     2800    // шаг автодемо (перебор эмоций)
#define AUTOANIM_MIN_S   10.0f   // «скучающие» анимации в IDLE
#define AUTOANIM_MAX_S   22.0f

// ------------------------------- Настройки (NVS) ---------------------------
// provider: "offline" | "local" | "openai"
//   offline — демо-мозг, работает сразу, без сети;
//   local   — свой ИИ на ПК (Ollama / LM Studio / llama.cpp), без ключей;
//   openai  — любой OpenAI-совместимый API (OpenAI, OpenRouter, GigaChat-прокси).
struct Settings {
  String provider   = "offline";
  String oai_base   = "";                // например http://192.168.1.50:11434/v1
  String oai_key    = "";
  String oai_model  = "gpt-4o-mini";
  String loc_base   = "";                // например http://192.168.1.50:11434/v1
  String loc_model  = "";                // например qwen2.5:3b
  String robot_name = "Робот";
  String user_name  = "Хозяин";
  bool   demo       = false;             // автодемо-перебор эмоций
  String wifi_ssid  = "Xiaomi";
  String wifi_pass  = "99110765";
};

#define NVS_NAMESPACE "robotface"

void loadSettings(Settings &s);           // реализация в main.cpp
void saveSettings(const Settings &s);
extern Settings g_set;                    // глобальные настройки (заполняются в setup)
