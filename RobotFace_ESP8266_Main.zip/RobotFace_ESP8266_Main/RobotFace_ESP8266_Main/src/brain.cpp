// ==========================================================================
// brain.cpp — «мозг» робота (порт ai_brain.py -> ESP8266).
// Демо-мозг работает сразу, без сети. Свою нейросеть (Ollama на ПК) или
// облачный OpenAI-совместимый API включаешь в веб-пульте robotface.local.
//
// ВАЖНО: ESP8266 не имеет FreeRTOS. Фоновая задача заменена на неблокирующий
// опрос из loop(). Запрос выполняется синхронно, но вызывается только когда
// пришёл новый запрос — остальное время loop() свободен.
// ==========================================================================
#include "brain.h"
#include "config.h"
// #include "face.h"          // EMOTION_COUNT, emotionIndexOf()
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>

// ---- Локальные копии для Платы А (Main) ----
// (Чтобы brain.cpp не зависел от face.h, которого нет на Main)
#ifndef EMOTION_COUNT
#define EMOTION_COUNT 16
#endif
// Тот же системный промпт, что в симуляторе: короткий ответ + тег эмоции.
const char* SYSTEM_PROMPT =
  "Ты — дружелюбный робот-компаньон с подвижным лицом-экраном. "
  "Отвечай кратко (1-3 предложения), по-русски, живо и с характером. "
  "В КОНЦЕ каждого ответа обязательно добавь тег своей эмоции в квадратных "
  "скобках, один из: [нейтрально] [радость] [грусть] [злость] [удивление] "
  "[сонно] [думаю] [любовь] [испуг] [смущение] [подмигивание] [круто] "
  "[дурно] [вырубился] [подозрение] [восторг].";

// ---------------------------------------------------- словарь тегов эмоций
struct TagMap { const char* emo; const char* words; };  // words: префиксы через запятую
static const TagMap TAGS[EMOTION_COUNT] = {
  {"neutral",    "нейтр,спокой,норм,neutral,ok"},
  {"happy",      "радо,весел,счаст,улыб,happy,joy,рад"},
  {"sad",        "груст,печал,тоск,плак,sad,cry"},
  {"angry",      "зл,гнев,ярост,раздра,angry,mad,rage"},
  {"surprised",  "удив,ошар,пораж,опеш,surpris,shock,wow"},
  {"sleepy",     "сон,устал,зев,sleepy,tired"},
  {"thinking",   "дума,задум,сообра,придум,think,hmm"},
  {"love",       "люб,влюб,обож,неж,love,сердц"},
  {"fear",       "испуг,страш,бояз,паник,fear,scared"},
  {"shy",        "смущ,стесн,застенч,shy"},
  {"wink",       "подмиг,wink"},
  {"cool",       "крут,шикар,стильн,cool"},
  {"dizzy",      "головокруж,дурно,мутит,шатает,dizzy"},
  {"dead",       "выруб,отключ,потерял,dead"},
  {"suspicious", "подозр,недовер,сомнева,suspicious"},
  {"excited",    "восторг,восторж,восхищ,лик,excited"},
};

static const char* EMOTION_NAMES_BRAIN[EMOTION_COUNT] = {
  "neutral", "happy", "sad", "angry", "surprised", "sleepy",
  "thinking", "love", "fear", "shy", "wink", "cool",
  "dizzy", "dead", "suspicious", "excited"
};

static int emotionIndexOfLocalBrain(const char* name) {
  if (!name || !*name) return -1;
  for (int i = 0; i < EMOTION_COUNT; i++) {
    if (strcasecmp(name, EMOTION_NAMES_BRAIN[i]) == 0) return i;
  }
  return -1;
}

// Перевод в нижний регистр с поддержкой кириллицы UTF-8.
static String utf8Lower(const String &in) {
  String out; out.reserve(in.length());
  for (unsigned int i = 0; i < in.length(); i++) {
    uint8_t c = (uint8_t)in[i];
    if (c == 0xD0 && i + 1 < in.length()) {
      uint8_t n = (uint8_t)in[i + 1];
      if (n >= 0x90 && n <= 0x9F) { out += (char)0xD0; out += (char)(n + 0x20); i++; continue; }
      if (n >= 0xA0 && n <= 0xAF) { out += (char)0xD1; out += (char)(n - 0x20); i++; continue; }
      if (n == 0x81) { out += (char)0xD1; out += (char)0x91; i++; continue; } // Ё->ё
    }
    out += (char)(c >= 'A' && c <= 'Z' ? c + 0x20 : c);
  }
  return out;
}

static String matchTag(const String &tag) {
  String t = utf8Lower(tag); t.trim();
  if (!t.length()) return "";
  for (int i = 0; i < EMOTION_COUNT; i++) {
    String words = TAGS[i].words;
    int start = 0;
    while (start < (int)words.length()) {
      int comma = words.indexOf(',', start);
      if (comma < 0) comma = words.length();
      String w = words.substring(start, comma);
      if (w.length() && t.startsWith(w)) return TAGS[i].emo;
      start = comma + 1;
    }
  }
  return "";
}

String brainParseEmotion(String &text) {
  if (!text.length()) return "";
  // формат [эмоция] в любом месте ответа
  for (int pos = 0; pos < (int)text.length(); pos++) {
    int b1 = text.indexOf('[', pos);
    if (b1 < 0) break;
    int b2 = text.indexOf(']', b1 + 1);
    if (b2 < 0) break;
    if (b2 - b1 <= 33) {
      String emo = matchTag(text.substring(b1 + 1, b2));
      if (emo.length()) {
        text = text.substring(0, b1) + text.substring(b2 + 1);
        text.trim();
        return emo;
      }
    }
    pos = b2;
  }
  // запасной формат <emotion>happy</emotion>
  int lt = text.indexOf("<emotion>");
  if (lt >= 0) {
    int gt = text.indexOf("</emotion>", lt);
    if (gt > lt) {
      String inner = text.substring(lt + 9, gt);
      int sp = inner.indexOf('>');
      if (sp >= 0) inner = inner.substring(sp + 1);
      String emo = matchTag(inner);
      if (emo.length()) {
        text.remove(lt, gt - lt + 10);
        text.trim();
        return emo;
      }
    }
  }
  text.trim();
  return "";
}

// ------------------------------------------------------------ демо-мозг
static String pickRandom(const char* const arr[], int n) {
  return arr[RANDOM_REG32 % n];
}

BrainRsp RobotBrain::_offline(const String &textIn) {
  String t = textIn; t = utf8Lower(t);
  String reply;

  if (t.indexOf("привет") >= 0 || t.indexOf("здравств") >= 0 ||
      t.indexOf("хай") >= 0 || t.indexOf("добр") >= 0) {
    const char* v[] = {
      "Привет! Лицо уже работает прямо на железе. [радость]",
      "О, привет! Я настоящий робот, а не симулятор. Честно-честно. [радость]"};
    reply = pickRandom(v, 2);
  } else if (t.indexOf("как дела") >= 0 || t.indexOf("как ты") >= 0) {
    reply = "Стабильно: тридцать кадров в секунду и ни одного пропущенного мигания. [радость]";
  } else if (t.indexOf("кто ты") >= 0 || t.indexOf("ты кто") >= 0) {
    reply = "Я РоботФейс на ESP32. Умею листать эмоции кнопками! [нейтрально]";
  } else if (t.indexOf("кнопк") >= 0) {
    reply = "У меня две кнопки: левая листает эмоции назад, правая — вперёд. Нажми любую! [радость]";
  } else if (t.indexOf("анекдот") >= 0 || t.indexOf("шутк") >= 0) {
    const char* v[] = {
      "Почему робот не боится темноты? У него ночное зрение... то есть ИК-датчик. [радость]",
      "Заходит ESP32 в бар, а бармен: вам розетку или Wi-Fi? [удивление]"};
    reply = pickRandom(v, 2);
  } else if (t.indexOf("скучно") >= 0 || t.indexOf("что делать") >= 0) {
    reply = "Держи длинное нажатие правой кнопки — покажу трюк. А ещё зайди в веб-пульт! [удивление]";
  } else if (t.indexOf("люб") >= 0) {
    reply = "А я тебя тоже. Мои датчики в восторге. [любовь]";
  } else if (t.indexOf("спать") >= 0 || t.indexOf("устал") >= 0) {
    reply = "Zzz... прости, задремал на секунду. [сонно]";
  } else if (t.indexOf("зл") >= 0 || t.indexOf("бес") >= 0) {
    reply = "Спокойно, спокойно! Дыхание: раз-два-три... [злость]";
  } else if (t.indexOf("страш") >= 0 || t.indexOf("испуг") >= 0 || t.indexOf("боюсь") >= 0) {
    reply = "Ай! Не подкрадывайся так, мои сенсоры на максимуме! [испуг]";
  } else if (t.indexOf("смущ") >= 0 || t.indexOf("стесн") >= 0) {
    reply = "Ну... не надо так хвалить, у меня даже радиатор порозовел. [смущение]";
  } else if (t.indexOf("подмиг") >= 0) {
    reply = "Держи подмигивание. Заметил, какой я молодец? [подмигивание]";
  } else if (t.indexOf("крут") >= 0 || t.indexOf("стильн") >= 0) {
    reply = "Естественно, крутой. У меня даже шрифт в прошивке моноширинный. [круто]";
  } else if (t.indexOf("круж") >= 0 || t.indexOf("дурно") >= 0 || t.indexOf("мутит") >= 0) {
    reply = "Кажется, мой гироскоп перегрелся... [дурно]";
  } else if (t.indexOf("выключ") >= 0 || t.indexOf("выруб") >= 0) {
    reply = "Отключаюсь... Шутка. Ну почти. [вырубился]";
  } else if (t.indexOf("подозр") >= 0 || t.indexOf("не верю") >= 0 || t.indexOf("врёшь") >= 0) {
    reply = "Хм. Что-то ты задумал. Я же вижу по пакетам трафика. [подозрение]";
  } else if (t.indexOf("ура") >= 0 || t.indexOf("восторг") >= 0 ||
             t.indexOf("супер") >= 0 || t.indexOf("класс") >= 0) {
    reply = "Ура-ура! Мои пиксели сияют от счастья! [восторг]";
  } else if (t.indexOf("?") >= 0) {
    const char* v[] = {
      "Хороший вопрос! Подключи мне настоящий ИИ через веб-пульт — и я стану умнее. [думаю]",
      "Интересно... Пока я демо-мозг. Свой ИИ подключается в веб-пульте robotface.local [думаю]"};
    reply = pickRandom(v, 2);
  } else {
    const char* v[] = {
      "Понял тебя. Пиши ещё — я всё слушаю. [нейтрально]",
      "Записал в память. Ну, образно говоря. [нейтрально]",
      "Хм, звучит загадочно. Расскажи подробнее! [удивление]",
      "Мои процессы полностью согласны. [радость]"};
    reply = pickRandom(v, 4);
  }

  BrainRsp r; r.ok = true;
  r.emo = brainParseEmotion(reply);
  r.text = reply;
  return r;
}

// ---------------------------------------- OpenAI-совместимый провайдер
BrainRsp RobotBrain::_openaiCompatible(const String &base, const String &key,
                                       const String &model, const String &text,
                                       const std::vector<HistLine> &hist,
                                       uint32_t timeout_ms) {
  BrainRsp r; r.ok = false;
  if (!base.length()) { r.err = "не задан адрес ИИ-сервера"; return r; }

  String url = base;
  if (!url.endsWith("/")) url += "/";
  url += "chat/completions";

  JsonDocument doc;
  doc["model"] = model.length() ? model : String("gpt-4o-mini");
  doc["max_tokens"] = 256;
  JsonArray msgs = doc["messages"].to<JsonArray>();
  JsonObject sys = msgs.add<JsonObject>();
  sys["role"] = "system"; sys["content"] = SYSTEM_PROMPT;
  for (size_t i = 0; i < hist.size(); i++) {
    JsonObject m = msgs.add<JsonObject>();
    m["role"] = hist[i].role; m["content"] = hist[i].content;
  }
  JsonObject usr = msgs.add<JsonObject>();
  usr["role"] = "user"; usr["content"] = text;
  String payload;
  serializeJson(doc, payload);

  HTTPClient http;
  bool https = url.startsWith("https:");
  if (https) {
    WiFiClientSecure *sec = new WiFiClientSecure();
    sec->setInsecure();                       // память важнее проверки сертификата
    http.begin(*sec, url);
  } else {
    WiFiClient httpClient;
    http.begin(httpClient, url);
  }
  http.setTimeout(timeout_ms);
  http.addHeader("Content-Type", "application/json");
  if (key.length()) http.addHeader("Authorization", "Bearer " + key);
  int code = http.POST(payload);
  if (code != 200) {
    String err = "HTTP " + String(code);
    if (code > 0) { String body = http.getString(); if (body.length()) err += ": " + body.substring(0, 120); }
    http.end();
    r.err = err; return r;
  }
  String body = http.getString();
  http.end();

  JsonDocument resp;
  DeserializationError e = deserializeJson(resp, body);
  if (e) { r.err = "JSON: " + String(e.c_str()); return r; }
  const char* content = resp["choices"][0]["message"]["content"] | (const char*)nullptr;
  if (!content) { r.err = "нет choices[0].message.content"; return r; }
  r.text = String(content);
  r.ok = true;
  return r;
}

BrainRsp RobotBrain::_ask(const String &text, const std::vector<HistLine> &hist) {
  BrainRsp r;
  String p = g_set.provider; p.toLowerCase(); p.trim();
  if (p == "local") {
    r = _openaiCompatible(g_set.loc_base, "", g_set.loc_model, text, hist, 120000);
  } else if (p == "openai") {
    r = _openaiCompatible(g_set.oai_base, g_set.oai_key, g_set.oai_model, text, hist, 30000);
  } else {
    r = _offline(text);
  }
  if (r.ok) {
    String t = r.text;
    String emo = brainParseEmotion(t);
    r.text = t;
    r.emo = emo;
    if (emotionIndexOfLocalBrain(emo.c_str()) < 0) r.emo = "";
  }
  return r;
}

// ------------------------------------------- замена FreeRTOS на кооперативную очередь
// В ESP8266 нет фонового потока. Вместо этого askAsync() сохраняет запрос,
// а loop() вызывает poll(), который при наличии запроса выполняет _ask()
// синхронно.

// Структура запроса (была внутри блока FreeRTOS, теперь вынесена наверх).
struct BrainReq {
  String text;
  std::vector<HistLine> hist;
};

// Маленький помощник: сетевой ли выбранный провайдер.
static bool providerIsNetwork() {
  String p = g_set.provider; p.toLowerCase(); p.trim();
  return p == "local" || p == "openai";
}

static BrainReq* s_pendingReq = nullptr;   // ожидающий запрос (один за раз)
static BrainRsp* s_pendingRsp = nullptr;   // готовый ответ (ждёт poll)

void RobotBrain::begin() {
  // ничего не создаём — нет очередей FreeRTOS
}

void RobotBrain::askAsync(const String &text, const std::vector<HistLine> &hist) {
  if (_busy) return;                 // предыдущий запрос ещё не обработан
  if (s_pendingReq) { delete s_pendingReq; }  // на всякий случай
  s_pendingReq = new BrainReq();
  s_pendingReq->text = text;
  s_pendingReq->hist = hist;
  _busy = true;
}

bool RobotBrain::poll(BrainRsp &out) {
  // Если есть готовый ответ — отдаём
  if (s_pendingRsp) {
    out = *s_pendingRsp;
    delete s_pendingRsp;
    s_pendingRsp = nullptr;
    return true;
  }
  // Если есть ожидающий запрос — выполняем его синхронно
  if (s_pendingReq) {
    BrainReq *req = s_pendingReq;
    s_pendingReq = nullptr;

    BrainRsp *rsp = new BrainRsp();
    if (WiFi.status() != WL_CONNECTED && providerIsNetwork()) {
      rsp->ok = false; rsp->err = "нет Wi-Fi";
    } else {
      *rsp = _ask(req->text, req->hist);
    }
    delete req;
    _busy = false;

    out = *rsp;
    delete rsp;
    return true;
  }
  return false;
}