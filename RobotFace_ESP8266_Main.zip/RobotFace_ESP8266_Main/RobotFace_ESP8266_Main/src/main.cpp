#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <espnow.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include "config.h"
#include "brain.h"
#include "webui.h"

// MAC-адрес Платы Б
uint8_t receiverMac[] = {0x80, 0x7D, 0x3A, 0x1A, 0x94, 0x2D}; 


// Структура команды (должна совпадать на обеих платах)
typedef struct struct_command {
  int emotion;      // -1 = не менять, >=0 = индекс, -2 = next, -3 = prev
  int motorLeft;
  int motorRight;
  int anim;         // -1 = нет анимации, >=0 = индекс анимации
  int state;        // -1 = нет смены состояния, 0..3 = IDLE/LISTEN/THINK/SPEAK
} struct_command;

struct_command myCmd;
bool espNowReady = false;
int g_currentEmotion = 0;
int g_currentState = 0;
Settings g_set;
RobotBrain g_brain;
std::vector<HistLine> g_hist;
float g_fps = 0;
bool g_apMode = false;
ESP8266WebServer server(80);

void onDataRecv(uint8_t *mac, uint8_t *incomingData, uint8_t len) {
  struct_command status;
  memcpy(&status, incomingData, sizeof(status));
  g_currentEmotion = status.emotion;
  g_currentState = status.state;
}

// --- Отправка команды на Плату Б ---
void sendCommand(int emotion, int left, int right, int anim, int state) {
  if (!espNowReady) return;
  myCmd.emotion = emotion;
  myCmd.motorLeft = left;
  myCmd.motorRight = right;
  myCmd.anim = anim;
  myCmd.state = state;
  esp_now_send(receiverMac, (uint8_t *) &myCmd, sizeof(myCmd));
}

// --- Вспомогательные функции (были в старом main.cpp) ---
void robotActivity() {
  // На Main нет лица, поэтому просто заглушка (или можно мигать светодиодом)
}

void robotToggleDemo() {
  g_set.demo = !g_set.demo;
  saveSettings(g_set);
  Serial.printf("[demo] автодемо: %s\n", g_set.demo ? "ВКЛ" : "ВЫКЛ");
}

void robotSubmitChat(const String &text) {
  robotActivity();
  HistLine h; h.role = "user"; h.content = text;
  g_hist.push_back(h);
  while (g_hist.size() > 8) g_hist.erase(g_hist.begin());
  // На Main нет g_face, поэтому не ставим ST_THINK, просто отправляем в мозг
  g_brain.askAsync(text, g_hist);
}

// --- Настройки (LittleFS + JSON) ---
static const char *SETTINGS_FILE = "/settings.json";

void loadSettings(Settings &s) {
  if (!LittleFS.begin()) {
    Serial.println("[настройки] LittleFS не смонтирован");
    return;
  }
  File f = LittleFS.open(SETTINGS_FILE, "r");
  if (!f) {
    Serial.println("[настройки] файла нет, используются значения по умолчанию");
    return;
  }

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, f);
  f.close();
  if (err) {
    Serial.printf("[настройки] ошибка JSON: %s\n", err.c_str());
    return;
  }

  s.provider   = doc["provider"]  | s.provider;
  s.oai_base   = doc["oai_base"]  | s.oai_base;
  s.oai_key    = doc["oai_key"]   | s.oai_key;
  s.oai_model  = doc["oai_model"] | s.oai_model;
  s.loc_base   = doc["loc_base"]  | s.loc_base;
  s.loc_model  = doc["loc_model"] | s.loc_model;
  s.robot_name = doc["rname"]     | s.robot_name;
  s.user_name  = doc["uname"]     | s.user_name;
  s.demo       = doc["demo"]      | s.demo;
  s.wifi_ssid  = doc["w_ssid"]    | s.wifi_ssid;
  s.wifi_pass  = doc["w_pass"]    | s.wifi_pass;

  Serial.println("[настройки] загружены из LittleFS");
}

void saveSettings(const Settings &s) {
  if (!LittleFS.begin()) {
    Serial.println("[настройки] LittleFS не смонтирован, сохранить нельзя");
    return;
  }

  JsonDocument doc;
  doc["provider"]  = s.provider;
  doc["oai_base"]  = s.oai_base;
  doc["oai_key"]   = s.oai_key;
  doc["oai_model"] = s.oai_model;
  doc["loc_base"]  = s.loc_base;
  doc["loc_model"] = s.loc_model;
  doc["rname"]     = s.robot_name;
  doc["uname"]     = s.user_name;
  doc["demo"]      = s.demo;
  doc["w_ssid"]    = s.wifi_ssid;
  doc["w_pass"]    = s.wifi_pass;

  File f = LittleFS.open(SETTINGS_FILE, "w");
  if (!f) {
    Serial.println("[настройки] не удалось открыть файл для записи");
    return;
  }
  serializeJson(doc, f);
  f.close();
  Serial.println("[настройки] сохранены в LittleFS");
}

// --- Инициализация ---
void setup() {
  Serial.begin(115200);
  delay(150);
  Serial.println("\n[Main] RobotFace Main");

  esp_now_register_recv_cb(onDataRecv);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  if (esp_now_init() != 0) {
    Serial.println("[Main] ESP-NOW init failed");
    return;
  }
  esp_now_set_self_role(ESP_NOW_ROLE_COMBO);
  esp_now_add_peer(receiverMac, ESP_NOW_ROLE_COMBO, 1, NULL, 0);
  espNowReady = true;
  Serial.println("[Main] ESP-NOW ready");

  // Файловая система для настроек
  if (!LittleFS.begin()) {
    Serial.println("[FS] LittleFS не смонтирован, форматирую...");
    LittleFS.format();
    LittleFS.begin();
  }

  loadSettings(g_set);
  g_brain.begin();

  // Wi-Fi для веб-интерфейса
  bool sta = false;
  if (g_set.wifi_ssid.length()) {
    WiFi.mode(WIFI_STA);
    WiFi.begin(g_set.wifi_ssid.c_str(), g_set.wifi_pass.c_str());
    uint32_t t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < 12000) {
      delay(250);
    }
    sta = (WiFi.status() == WL_CONNECTED);
  }
  if (sta) {
    g_apMode = false;
    Serial.printf("[Main] Wi-Fi OK, IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    WiFi.mode(WIFI_AP);
    WiFi.softAP("RobotFace", "12345678");
    g_apMode = true;
    Serial.println("[Main] AP mode");
  }

  webuiBegin(server);
  Serial.println("[Main] Ready");
}

void loop() {
  server.handleClient();
  BrainRsp rsp;
  while (g_brain.poll(rsp)) {
    if (rsp.ok) {
      // Если есть эмоция, отправляем её на Плату Б
      if (rsp.emo.length()) {
        // Здесь нужен локальный поиск эмоции по имени. 
        // Так как на Main нет face.h, используем простой перебор.
        const char* emo_names[] = {
          "neutral", "happy", "sad", "angry", "surprised", "sleepy",
          "thinking", "love", "fear", "shy", "wink", "cool",
          "dizzy", "dead", "suspicious", "excited"
        };
        int idx = -1;
        for (int i = 0; i < 16; i++) {
          if (strcasecmp(rsp.emo.c_str(), emo_names[i]) == 0) { idx = i; break; }
        }
        if (idx >= 0) sendCommand(idx, 0, 0, -1, -1);
      }
      Serial.printf("[робот] %s\n", rsp.text.c_str());
    } else {
      Serial.printf("[мозг] ошибка: %s\n", rsp.err.c_str());
    }
  }
}