// ==========================================================================
// webui.cpp — веб-пульт RobotFace (для Платы А / Main)
// ==========================================================================
#include "webui.h"
#include "config.h"
#include "brain.h"
#include <ESP8266WiFi.h>
#include <ESP8266mDNS.h>
#include <ArduinoJson.h>

// ---- внешние объекты и функции (определены в main.cpp Платы А) ----
extern RobotBrain g_brain;
extern Settings   g_set;
extern void robotSubmitChat(const String &text);
extern void robotToggleDemo();
extern void robotActivity();
extern uint32_t lastActivityMs();
extern float g_fps;
extern bool g_apMode;
extern std::vector<HistLine> g_hist;

// Функция отправки команды (5 аргументов, как в main.cpp)
extern void sendCommand(int emotion, int left, int right, int anim, int state);

// Переменные статуса (определены в main.cpp)
extern int g_currentEmotion;
extern int g_currentState;

// --- Локальные копии массивов для webui ---
static const char* EMOTION_NAMES_LOCAL[] = {
  "neutral", "happy", "sad", "angry", "surprised", "sleepy",
  "thinking", "love", "fear", "shy", "wink", "cool",
  "dizzy", "dead", "suspicious", "excited"
};
static const char* EMOTION_RU_LOCAL[] = {
  "НЕЙТРАЛЬ", "РАДОСТЬ", "ГРУСТЬ", "ЗЛОСТЬ", "УДИВЛЕНИЕ", "СОНЛИВОСТЬ",
  "ЗАДУМА", "ЛЮБОВЬ", "ИСПУГ", "СМУЩЕНИЕ", "ПОДМИГ", "КРУТОЙ",
  "ДУРНО", "ОТКЛЮЧЁН", "ПОДОЗРЕНИЕ", "ВОСТОРГ"
};
static const char* STATE_NAMES_LOCAL[] = {"IDLE", "LISTEN", "THINK", "SPEAK"};

static int emotionIndexOfLocal(const char* name) {
  if (!name || !*name) return -1;
  for (int i = 0; i < 16; i++) {
    if (strcasecmp(name, EMOTION_NAMES_LOCAL[i]) == 0) return i;
  }
  return -1;
}

static ESP8266WebServer *_srv = nullptr;

// ------------------------------------------------------------ HTML-страница
static const char INDEX_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>RobotFace — пульт</title><style>
:root{--bg:#0a0e14;--pn:#141a24;--bt:#1d2735;--ac:#3d8bfd;--tx:#dce6f2;--dim:#8296ad}
*{box-sizing:border-box;margin:0}
body{background:var(--bg);color:var(--tx);font:15px/1.45 system-ui,sans-serif;padding:14px;max-width:560px;margin:auto}
h1{font-size:19px;margin:4px 0 2px}#st{color:var(--dim);font-size:13px;margin-bottom:12px}
h2{font-size:13px;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);margin:16px 0 8px}
.row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
button{background:var(--bt);color:var(--tx);border:1px solid #2a3648;border-radius:10px;
padding:11px 6px;font-size:14px;cursor:pointer;transition:.15s}
button:active{transform:scale(.96)}
button.on{background:var(--ac);border-color:var(--ac);color:#fff}
button.big{font-size:16px;padding:14px 6px}
button.nav{background:#244a7d;border-color:#33619e;font-weight:600}
input,select{width:100%;background:#10151d;color:var(--tx);border:1px solid #2a3648;
border-radius:8px;padding:9px;font-size:14px;margin:3px 0 9px}
label{font-size:12px;color:var(--dim)}
#msg{position:fixed;bottom:12px;left:50%;transform:translateX(-50%);background:var(--ac);
color:#fff;padding:8px 18px;border-radius:20px;font-size:13px;opacity:0;transition:.3s}
#msg.show{opacity:1}
.pad{display:grid;grid-template-columns:repeat(3,76px);gap:8px;justify-content:center;margin-bottom:8px}
.drv{height:76px;font-size:28px;background:#244a7d;border-color:#33619e;touch-action:none;
user-select:none;-webkit-user-select:none}
.drv.stp{background:#7d2424;border-color:#9e3333}
</style></head><body>
<h1>RobotFace — пульт робота</h1>
<div id="st">...</div>

<h2>Движение (держи кнопку — робот едет)</h2>
<div class="pad">
  <span></span><button class="drv" data-l="1" data-r="1">&#9650;</button><span></span>
  <button class="drv" data-l="-1" data-r="1">&#9664;</button>
  <button class="drv stp" data-l="0" data-r="0">&#9632;</button>
  <button class="drv" data-l="1" data-r="-1">&#9654;</button>
  <span></span><button class="drv" data-l="-1" data-r="-1">&#9660;</button><span></span>
</div>
<label>Скорость: <span id="spv">180</span></label>
<input id="spd" type="range" min="60" max="255" value="180" style="padding:0">

<h2>Листать эмоции (те же 2 кнопки, что на корпусе)</h2>
<div class="row">
  <button class="big nav" onclick="api('/api/prev')">&#9664; Назад</button>
  <button class="big nav" onclick="api('/api/next')">Вперёд &#9654;</button>
</div>

<h2>16 эмоций</h2><div class="grid" id="emo"></div>

<h2>Анимации</h2><div class="grid" id="anim"></div>

<h2>Состояние</h2><div class="grid" id="states" style="grid-template-columns:repeat(4,1fr)"></div>
<div class="row" style="margin-top:8px">
  <button onclick="api('/api/demo')">Автодемо: вкл/выкл</button>
  <button onclick="api('/api/wake')">Разбудить / активность</button>
</div>

<h2>Мозг (сохраняется в памяти робота)</h2>
<label>Провайдер</label>
<select id="provider"><option value="offline">Демо-мозг (офлайн)</option>
<option value="local">Свой ИИ: Ollama / LM Studio / llama.cpp</option>
<option value="openai">OpenAI-совместимый API (облако)</option></select>
<label>Адрес (base_url) — для Ollama: http://IP_компьютера:11434/v1</label>
<input id="base">
<label>API-ключ (для облаков; Ollama не нужен)</label>
<input id="key">
<label>Модель (например qwen2.5:3b или gpt-4o-mini)</label>
<input id="model">
<label>Имя робота</label><input id="robot_name">
<label>Ваше имя</label><input id="user_name">
<button style="width:100%;margin-top:6px" onclick="saveSettings()">Сохранить настройки</button>

<h2>Wi-Fi (подключение к роутеру)</h2>
<label>SSID</label><input id="w_ssid">
<label>Пароль</label><input id="w_pass">
<button style="width:100%;margin-top:6px" onclick="saveWifi()">Подключить и перезагрузить робота</button>

<h2>Чат с роботом</h2>
<div id="chatlog" style="background:var(--pn);border:1px solid #2a3648;border-radius:8px;height:150px;overflow-y:auto;padding:8px;margin-bottom:8px;font-size:13px;"></div>
<div style="display:flex;gap:8px;">
  <input id="chatinput" placeholder="Напиши роботу..." onkeydown="if(event.key==='Enter')sendChat()" style="margin:0;flex:1;">
  <button onclick="sendChat()" style="padding:9px 16px;">Отправить</button>
</div>
<div id="msg"></div>
<script>
const EMO=[["neutral","НЕЙТРАЛЬ"],["happy","РАДОСТЬ"],["sad","ГРУСТЬ"],["angry","ЗЛОСТЬ"],
["surprised","УДИВЛЕНИЕ"],["sleepy","СОННОСТЬ"],["thinking","ЗАДУМА"],["love","ЛЮБОВЬ"],
["fear","ИСПУГ"],["shy","СМУЩЕНИЕ"],["wink","ПОДМИГ"],["cool","КРУТОЙ"],
["dizzy","ДУРНО"],["dead","ОТКЛЮЧЁН"],["suspicious","ПОДОЗРЕНИЕ"],["excited","ВОСТОРГ"]];
const ANIM=[["look_around","Осмотр"],["double_blink","Двойное мигание"],["v_scan","Скан вниз"],
["h_scan","Скан вбок"],["pulse","Пульс"]];
const STATES=[["IDLE","ОЖИДАНИЕ"],["LISTEN","СЛУШАЮ"],["THINK","ДУМАЮ"],["SPEAK","ГОВОРЮ"]];
let cur={};
function $(id){return document.getElementById(id)}
function el(tag,cls,txt,fn){const b=document.createElement(tag==='button'?'button':'div');
if(tag==='button'){b.textContent=txt;if(fn)b.onclick=fn}return b}
EMO.forEach(([id,ru])=>{const b=el('button','b',ru,()=>api('/api/emotion?name='+id));b.id='e_'+id;$('emo').appendChild(b)});
ANIM.forEach(([id,ru])=>{const b=el('button','b',ru,()=>api('/api/anim?name='+id));$('anim').appendChild(b)});
STATES.forEach(([id,ru])=>{const b=el('button','b',ru,()=>api('/api/state?name='+id));b.id='s_'+id;$('states').appendChild(b)});
function msg(t){const m=$('msg');m.textContent=t;m.classList.add('show');setTimeout(()=>m.classList.remove('show'),1800)}
function api(u){fetch(u).then(r=>r.json()).then(j=>{if(j.err)msg('Ошибка: '+j.err);else msg('Готово');refresh()}).catch(()=>msg('Нет связи'))}
function refresh(){fetch('/api/status').then(r=>r.json()).then(j=>{
 $('st').textContent=(j.ap?'AP: ':'IP: ')+j.ip+' * '+j.state+' * '+j.emotion_ru+
 ' ('+(j.idx+1)+'/16) * мозг: '+j.provider+' * '+Math.round(j.fps)+' к/с * своб. памяти: '+Math.round(j.heap/1024)+' КБ';
 cur=j;
 EMO.forEach(([id])=>$('e_'+id).classList.toggle('on',id===j.emotion));
 STATES.forEach(([id])=>$('s_'+id).classList.toggle('on',id===j.state));
}).catch(()=>{})}
function saveSettings(){
 fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({provider:$('provider').value,base:$('base').value,key:$('key').value,
 model:$('model').value,robot_name:$('robot_name').value,user_name:$('user_name').value})})
 .then(r=>r.json()).then(j=>msg(j.err?('Ошибка: '+j.err):'Настройки сохранены')).catch(()=>msg('Нет связи'))}
function saveWifi(){
 fetch('/api/wifi',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({ssid:$('w_ssid').value,pass:$('w_pass').value})})
 .then(()=>msg('Подключаюсь... робот перезагрузится')).catch(()=>msg('Нет связи'))}
function sendChat() {
  const inp = $('chatinput');
  const txt = inp.value.trim();
  if (!txt) return;
  const log = $('chatlog');
  log.innerHTML += '<div style="color:#3d8bfd;margin:4px 0;"><b>Вы:</b> ' + txt + '</div>';
  inp.value = '';
  log.scrollTop = log.scrollHeight;
  fetch('/api/chat', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({text: txt})
  }).then(r => r.json()).then(j => {
    if (j.ok) {
      log.innerHTML += '<div style="color:#dce6f2;margin:4px 0;"><b>Робот:</b> ' + j.reply + '</div>';
    } else {
      log.innerHTML += '<div style="color:#ff6b6b;margin:4px 0;"><b>Ошибка:</b> ' + (j.err || 'нет ответа') + '</div>';
    }
    log.scrollTop = log.scrollHeight;
  }).catch(() => {
    log.innerHTML += '<div style="color:#ff6b6b;margin:4px 0;">Нет связи с платой</div>';
    log.scrollTop = log.scrollHeight;
  });
}
// ---- движение: пока кнопка зажата, шлём команду каждые 150 мс ----
let drvT=null,drv=[0,0];
const spd=$('spd');spd.oninput=()=>$('spv').textContent=spd.value;
function dsend(l,r){fetch('/api/drive?l='+l+'&r='+r).catch(()=>{})}
function dstart(b){const k=+spd.value;drv=[b.dataset.l*k,b.dataset.r*k];
 dsend(drv[0],drv[1]);clearInterval(drvT);drvT=setInterval(()=>dsend(drv[0],drv[1]),150)}
function dstop(){if(drvT===null)return;clearInterval(drvT);drvT=null;dsend(0,0)}
document.querySelectorAll('.drv').forEach(b=>{
 b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);dstart(b)});
 b.addEventListener('pointerup',dstop);b.addEventListener('pointercancel',dstop);
 b.addEventListener('contextmenu',e=>e.preventDefault())});
window.addEventListener('blur',dstop);
document.addEventListener('visibilitychange',()=>{if(document.hidden)dstop()});
setInterval(refresh,2500);refresh();
</script></body></html>)rawliteral";

// ------------------------------------------------------------ хелперы
static void sendJson(const String &s) {
  _srv->send(200, "application/json", s);
}
static void sendOk() {
  sendJson("{\"ok\":1}");
}

static void handleRoot() {
  robotActivity();
  _srv->send_P(200, "text/html", INDEX_HTML);
}

static void handleStatus() {
  String s = "{";
  s += "\"ok\":1,\"state\":\"" + String(STATE_NAMES_LOCAL[g_currentState]) + "\"";
  s += ",\"emotion\":\"" + String(EMOTION_NAMES_LOCAL[g_currentEmotion]) + "\"";
  s += ",\"emotion_ru\":\"" + String(EMOTION_RU_LOCAL[g_currentEmotion]) + "\"";
  s += ",\"idx\":" + String(g_currentEmotion);
  s += ",\"provider\":\"" + g_set.provider + "\"";
  s += ",\"fps\":" + String(g_fps, 1);
  s += ",\"heap\":" + String(ESP.getFreeHeap());
  s += ",\"ip\":\"" + (g_apMode ? WiFi.softAPIP().toString() : WiFi.localIP().toString()) + "\"";
  s += ",\"ap\":" + String(g_apMode ? "true" : "false");
  s += "}";
  sendJson(s);
}

static void handleEmotion() {
  int emo = -1;
  if (_srv->hasArg("name")) {
    emo = emotionIndexOfLocal(_srv->arg("name").c_str());
  } else if (_srv->hasArg("i")) {
    emo = _srv->arg("i").toInt();
  }
  if (emo >= 0) sendCommand(emo, 0, 0, -1, -1);
  sendOk();
}

static void handleNext() { sendCommand(-2, 0, 0, -1, -1); sendOk(); }
static void handlePrev() { sendCommand(-3, 0, 0, -1, -1); sendOk(); }

static void handleAnim() {
  String n = _srv->hasArg("name") ? _srv->arg("name") : "";
  int animIdx = -1;
  const char* animNames[] = {"look_around","double_blink","v_scan","h_scan","pulse"};
  for (int i = 0; i < 5; i++) {
    if (n == animNames[i]) { animIdx = i; break; }
  }
  if (animIdx >= 0) sendCommand(-1, 0, 0, animIdx, -1);
  sendOk();
}

static void handleState() {
  String n = _srv->hasArg("name") ? _srv->arg("name") : "";
  n.toUpperCase();
  int stateIdx = -1;
  for (int i = 0; i < 4; i++) {
    if (n == STATE_NAMES_LOCAL[i]) { stateIdx = i; break; }
  }
  if (stateIdx >= 0) sendCommand(-1, 0, 0, -1, stateIdx);
  sendOk();
}

static void handleDrive() {
  int l = _srv->hasArg("l") ? _srv->arg("l").toInt() : 0;
  int r = _srv->hasArg("r") ? _srv->arg("r").toInt() : 0;
  sendCommand(-1, l, r, -1, -1);
  sendOk();
}

static void handleDemo() { robotToggleDemo(); sendOk(); }
static void handleWake() { sendCommand(0, 0, 0, -1, -1); sendOk(); }

static void handleSettings() {
  JsonDocument doc;
  DeserializationError e = deserializeJson(doc, _srv->arg("plain"));
  if (e) { sendJson("{\"err\":\"bad json\"}"); return; }
  if (!doc["provider"].isNull()) g_set.provider = doc["provider"].as<String>();
  if (!doc["base"].isNull()) {
    g_set.loc_base = doc["base"].as<String>();
    g_set.oai_base = doc["base"].as<String>();
  }
  if (!doc["key"].isNull())  g_set.oai_key = doc["key"].as<String>();
  if (!doc["model"].isNull()) {
    g_set.loc_model = doc["model"].as<String>();
    g_set.oai_model = doc["model"].as<String>();
  }
  if (!doc["robot_name"].isNull()) g_set.robot_name = doc["robot_name"].as<String>();
  if (!doc["user_name"].isNull())  g_set.user_name  = doc["user_name"].as<String>();
  saveSettings(g_set);
  sendOk();
}

static void handleWifi() {
  JsonDocument doc;
  DeserializationError e = deserializeJson(doc, _srv->arg("plain"));
  if (e) { sendJson("{\"err\":\"bad json\"}"); return; }
  g_set.wifi_ssid = doc["ssid"] | "";
  g_set.wifi_pass = doc["pass"] | "";
  saveSettings(g_set);
  sendJson("{\"ok\":1,\"msg\":\"rebooting\"}");
  delay(800);
  ESP.restart();
}

void webuiBegin(ESP8266WebServer &server) {
  _srv = &server;
  server.on("/",            handleRoot);
  server.on("/api/status",  handleStatus);
  server.on("/api/emotion", handleEmotion);
  server.on("/api/next",    handleNext);
  server.on("/api/prev",    handlePrev);
  server.on("/api/anim",    handleAnim);
  server.on("/api/state",   handleState);
  server.on("/api/demo",    handleDemo);
  server.on("/api/drive",   handleDrive);
  server.on("/api/wake",    handleWake);
  server.on("/api/settings",HTTP_POST, handleSettings);
  server.on("/api/wifi",    HTTP_POST, handleWifi);
  server.onNotFound(handleRoot);

  server.on("/api/chat", HTTP_POST, []() {
    JsonDocument doc;
    DeserializationError e = deserializeJson(doc, _srv->arg("plain"));
    if (e) { sendJson("{\"ok\":0,\"err\":\"bad json\"}"); return; }
    String text = doc["text"] | "";
    if (!text.length()) { sendJson("{\"ok\":0,\"err\":\"empty text\"}"); return; }
    robotSubmitChat(text);
    sendJson("{\"ok\":1,\"reply\":\"(робот думает...)\"}");
  });
  server.begin();
}